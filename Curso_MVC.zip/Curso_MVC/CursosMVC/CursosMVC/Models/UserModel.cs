﻿
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace CursosMVC.Models;

public class UserModel
{
    public int Id { get; set; }
    [Required(ErrorMessage = "Digite um nome de usuário!")]
    public string Nome { get; set; }
    [Required(ErrorMessage = "Selecione o tipo de usuário!")]
    public string TipoUsuario { get; set; }
    [Required(ErrorMessage = "Digite um email!")]
    public string Email { get; set; }
    [Required(ErrorMessage = "Digite uma senha!")]
    public string Senha { get; set; }
    public List<SelectListItem> Options { get; set; }

}
