﻿using CursosMVC.Data;
using CursosMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace CursosMVC.Controllers
{
    public class UserController : Controller
    {
        readonly private AppDbContext _db;
        public UserController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            IEnumerable<UserModel> users = _db.User;
            return View(users);
        }
        [HttpGet]
        public IActionResult Cadastrar()
        {

            var model = new UserModel
            {
                Options = GetSelectListOptions()
            };
            return View(model);
        }
        [HttpPost]
        public IActionResult Cadastrar(UserModel users)
        {
            if (ModelState.IsValid)
            {
                if (users.TipoUsuario == "null")
                {
                    return View();
                }
                _db.User.Add(users);
                _db.SaveChanges();

                return RedirectToAction("Index");
            }
            users.Options = GetSelectListOptions();
            return View(users);
        }

        [HttpGet]
        public IActionResult Editar(int? id) {
            if (id == null || id == 0) { 
                return NotFound();
            }
            UserModel user = _db.User.FirstOrDefault(x => x.Id == id);

            if (user == null) {
                return NotFound();
            }
            return View(user);
        }

        private List<SelectListItem> GetSelectListOptions()
        {
            return new List<SelectListItem>
            {
                new SelectListItem { Text = "Selecione...", Value = "" },
                new SelectListItem { Text = "Master", Value = "Master" },
                new SelectListItem { Text = "Estudante", Value = "Estudante" },
                new SelectListItem { Text = "Funcionário", Value = "Funcionário" }
            };
        }
    }
}
