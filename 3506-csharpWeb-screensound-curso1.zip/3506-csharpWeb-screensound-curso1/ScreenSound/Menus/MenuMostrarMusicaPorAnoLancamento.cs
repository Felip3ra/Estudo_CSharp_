﻿using ScreenSound.Banco;
using ScreenSound.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenSound.Menus;

internal class MenuMostrarMusicaPorAnoLancamento : Menu
{
    public override void Executar(DAL<Artista> artistaDAL)
    {
        base.Executar(artistaDAL);
        ExibirTituloDaOpcao("Registro de Lancamento");
        Console.Write("Digite o ano de lancamento: ");
        int ano = Convert.ToInt32(Console.ReadLine()!);
        DAL<Musica> musicalDal = new DAL<Musica>(new ScreenSoundContext());
        var anoLancamento = musicalDal.RecuperarMusicasPorAnoLancamento(x => x.AnoLancamento.Equals(ano));
        if (anoLancamento is not null)
        {
            foreach (var item in anoLancamento)
            {
                item.ExibirFichaTecnica();
            }
            Thread.Sleep(4000);
            Console.Clear();
        }
        else
        {
            Console.WriteLine($"\nNenhuma musica foi encontrada nesse ano digitado!");
            Console.WriteLine("Digite uma tecla para voltar ao menu principal");
            Console.ReadKey();
            Console.Clear();
        }
    }
}
